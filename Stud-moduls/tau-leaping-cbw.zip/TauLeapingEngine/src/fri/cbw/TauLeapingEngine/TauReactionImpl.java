/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.cbw.TauLeapingEngine;


public class TauReactionImpl extends TauReaction {
    
}
